
/* os module interface */

#ifndef Py_OSMODULE_H
#define Py_OSMODULE_H
#ifdef __cplusplus
extern "C" {
#endif

PyAPI_FUNC(PyObject *) PyOS_FSPath(PyObject *path);

#ifdef __cplusplus
}
#endif
#endif /* !Py_OSMODULE_H */
